<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/login.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
<div class="login-box d-flex flex-column">
      
  <div class="login-header">
    <h2> Login
      <p> Welcome to Fisherman Login Page</p>
    </h2>
  </div>

  <!-- form start -->
  <form method="POST" id="login_seller_form" name="login_seller_form" class="input-container d-flex flex-column">
    
    <div class="input-box  d-flex flex-column">
      <label for="user">Username</label>
      <div class="input-group">
        <input name="username" placeholder="Username or Email" type="text" id="user" class="form-control bg-second ">
        <button class="btn text-white" tabindex="-1"><i class="fa-solid fa-user"></i></button>
      </div>
    </div>

    <div class="input-box  d-flex flex-column">
      <label for="pass">Password</label>
      <div class="input-group">
        <input name="password" placeholder="********" type="password" id="pass" class="form-control bg-second ">
        <button class="btn text-white" tabindex="-1"><i class="fa-solid fa-eye"></i></button>
      </div>
    </div>

    <div class="pw-setting d-flex">
      <div class="remember">
        <input type="checkbox" id="remember">
        <label for="remember">Remember me</label>
      </div>
      <div class="forgot-pw">
        <a href="#">Forgot password</a>
      </div>
    </div>
    <input type="submit" class="input-submit" value="Login">

    <div class="register">
      <span>Don't have an account?
        <a href="<?php echo e(route('register_customer')); ?>" class="ms-1">Register</a>
      </span>
      <p class="">(or)</p> 
    </div>
    <div class="line-wpr green-bg">
      <a href="">
        <img class="icon_social" src="<?php echo e(asset('assets/icons/custom/line.png')); ?>" alt="Line">
        Login with Line
      </a>
    </div>
    <div class="icon-wpr">
      <a href=""><img class="icon_social" src="<?php echo e(asset('assets/icons/custom/google.png')); ?>" alt="Google"></a>
      <a href=""><img class="icon_social" src="<?php echo e(asset('assets/icons/custom/facebook.png')); ?>" alt="Facebook"></a>
    </div>
  </form>
  <!-- form end -->
</div>
<script>
   $(document).ready(function() {
     $.ajaxSetup({
             headers: {
                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
             }
         });
         $("#login_seller_form").submit(function(e) {
             e.preventDefault();
             var formData = new FormData(this);
             $.ajax({
                 url: "<?php echo e(route('login_store_customer')); ?>",
                 type: 'POST',
                 dataType: 'json',
                 data: formData,
                 contentType: false,
                 processData: false,
                 success: function(response) {
                     if (response.status == true) {
                         window.location.href = "<?php echo e(route('login_customer')); ?>";
                     } else{
                         if(response.message){
                             alert(response.message);
                         }
                     }
                 }
             });
         });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\fisherman-project\laravel\fisher-man\resources\views/customers/login.blade.php ENDPATH**/ ?>